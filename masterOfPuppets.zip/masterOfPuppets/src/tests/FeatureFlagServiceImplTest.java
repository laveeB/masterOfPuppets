package tests;


import org.junit.Test;

public class FeatureFlagServiceImplTest {

    @Test
    public void test1(){

    }


}