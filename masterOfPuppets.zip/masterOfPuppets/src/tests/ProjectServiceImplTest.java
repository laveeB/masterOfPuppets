package tests;

import static org.junit.Assert.assertEquals;

import impl.ProjectServiceImpl;
import interfaces.ProjectService;
import java.time.Instant;
import java.util.ArrayList;
import model.Feature;
import model.Project;
import org.junit.Test;

public class ProjectServiceImplTest{

    private ProjectService projectService;


    @Test
    public void test1(){


    }



}
