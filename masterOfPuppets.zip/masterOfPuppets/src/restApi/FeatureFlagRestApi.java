package restApi;

import interfaces.FeatureFlagService;
import java.util.ArrayList;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import model.Feature;

@Path("/{projectId}/features")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class FeatureFlagRestApi {


    private FeatureFlagService featureFlagService;


    @DELETE
    @Path("/{flagName}")
    public void deleteFlag(@PathParam("projectId") String projectId,
                           @PathParam("flagName") String flagName) {

        featureFlagService.delete(projectId, flagName);
    }

    @POST
    @Path("")
    public Feature createFlag(@PathParam("projectId") String projectId,
                              Feature feature) {

        return featureFlagService.createFlag(projectId, feature.getFeatureName(), feature.isEnabled());
    }

    @PUT
    @Path("/{flagName}")
    public void changeFlagName(@PathParam("projectId") String projectId,
                               @PathParam("flagName") String flagName,
                           String newFlagName) {

        featureFlagService.changeFlagName(projectId,flagName, newFlagName);
    }

    @PUT
    @Path("/{flagName}")
    public void changeFlagStatus(@PathParam("projectId") String projectId,
                               @PathParam("flagName") String flagName,
                               boolean isEnabled) {

        featureFlagService.changeFlagStatus(projectId,flagName,isEnabled);
    }
}