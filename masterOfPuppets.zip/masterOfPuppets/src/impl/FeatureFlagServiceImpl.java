package impl;

import interfaces.FeatureFlagService;
import interfaces.ProjectService;
import java.util.ArrayList;
import model.Feature;
import model.Project;

public class FeatureFlagServiceImpl implements FeatureFlagService {

    private ProjectService projectService;
    private FeatureFlagService featureFlagService;

    @Override
    public ArrayList<Feature> getFlags(String projectId) {

        Project project = projectService.getProject(projectId);

        return project.getFeaturesList();
    }

    @Override
    public Feature createFlag(String name, boolean isEnabled) {
        return new Feature(name, isEnabled);
    }

    @Override
    public void updateName(String projectId, String flagName, String newFlagName) {

        if (projectId != null && !flagName.isEmpty()) {
            Project project = projectService.getProject(projectId);
            ArrayList<Feature> featuresList = project.getFeaturesList();
            for (Feature flag : featuresList) {
                if (flag.getFeatureName().equals(flagName)) {
                    flag.setFeatureName(newFlagName);
                }
            }
        }
    }

    @Override
    public void updateStatus(Feature feature, boolean status) {

        feature.setStatus(status);
    }

    @Override
    public void delete(String projectId, String flagName) {

        if (projectId != null && !flagName.isEmpty()) {
            Project project = projectService.getProject(projectId);
            ArrayList<Feature> featuresList = project.getFeaturesList();
            Feature flag = featureFlagService.getFlag(flagName);
            if (featuresList.contains(flag)) {
                featuresList.remove(flag);
            }
        }

    }

    @Override
    public Feature getFlag(String name) {

        return null;
    }
}
