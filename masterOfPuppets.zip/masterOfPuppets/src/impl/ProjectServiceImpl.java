package impl;

import Data.DBResource;
import interfaces.ProjectService;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import model.Feature;
import model.Project;


public class ProjectServiceImpl implements ProjectService {

    private DBResource dbResource;

    public ArrayList<Project> getProjects() {

        ArrayList<Project> activeProjects = new ArrayList<>();
        ArrayList<Project> listOfProjects = new ArrayList<>();
        try {
            listOfProjects = dbResource.getProjectFromDB();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        for (Project project : listOfProjects) {
            if (checkDate(project.getCreatedDate(), project.getLastUpdatedDate())) {
                activeProjects.add(project);
            }
        }
        return activeProjects;
    }

    public Project getProject(String projectId) {

        for (Project project : getProjects()) {
            if (project.getProjectId().equals(projectId)) {
                return project;
            }
        }

        return null;
    }


    @Override
    public ArrayList<Feature> getProjectFeatureFlags(String projectId, String secretKey) {
        ArrayList<Project> projects = null;
        try {
            projects = dbResource.getProjectFromDB();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        ArrayList<Feature> features = null;
        try {
            features = dbResource.getFeatureFlagsFromDB(projectId);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        if (projects != null) {
            for (Project project : projects) {
                if (project.getProjectId().equals(projectId) && project.getSecretKey().equals(secretKey)) {
                    if (features != null) {
                        for (Feature feature : features) {
                            if (feature.getProjectId().equals(projectId)) {

                                return project.getFeaturesList();
                            }
                        }

                    }
                }
            }
        }

        return null;
    }


    @Override
    public Project createProject(String name) {

        Project project = new Project();

        project.setName(name);
        project.setCreatedDate(new Timestamp(System.currentTimeMillis()));
        project.setSecretKey(generateRandomChars());
        project.setProjectId(new Random() + "_" + project.getName());

        try {
            dbResource.saveProject(project);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        //save project somewhere

        return project;
    }

    @Override
    public String keySecretKey(String projectName) {

        ArrayList<Project> existingProjects = getProjects();

        for (Project project : existingProjects) {
            if (project.getName().equals(projectName)) {
                return project.getSecretKey();
            }
        }

        return null;
    }

    private Boolean checkDate(Timestamp createdDate, Timestamp lastUpdatedDate) {

        return lastUpdatedDate.after(createdDate) && lastUpdatedDate
                .before(new Timestamp(createdDate.getTime() + TimeUnit.DAYS.toMillis(30)));
    }

    private static String generateRandomChars() {

        String candidateChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        int length = 6;

        StringBuilder sb = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < length; i++) {
            sb.append(candidateChars.charAt(random.nextInt(candidateChars.length())));
        }

        return sb.toString();
    }

}
