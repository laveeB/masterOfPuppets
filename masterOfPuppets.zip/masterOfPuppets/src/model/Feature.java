package model;

public class Feature {

    private String featureName;
    private boolean isEnabled;
    private String projectId;

    public Feature(String featureName, boolean isEnabled, String projectId) {
        this.featureName = featureName;
        this.isEnabled = isEnabled;
        this.projectId = projectId;
    }


    public Feature() {
    }

    public String getFeatureName() {
        return featureName;
    }

    public void setFeatureName(String featureName) {
        this.featureName = featureName;
    }

    public boolean isEnabled() {
        return isEnabled;
    }

    public void setStatus(boolean enabled) {
        isEnabled = enabled;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }
}
