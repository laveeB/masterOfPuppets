package model;

import java.sql.Time;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;

public class Project {

    private String name;
    private String projectId;
    private String secretKey;
    private Timestamp createdDate;
    private Timestamp lastUpdatedDate;
    private ArrayList<Feature> featuresList;

    public Project(String name, String projectId, String secretKey, Timestamp createdDate, Timestamp lastUpdatedDate,
                   ArrayList<Feature> featuresList) {
        this.name = name;
        this.projectId = projectId;
        this.secretKey = secretKey;
        this.createdDate = createdDate;
        this.lastUpdatedDate = lastUpdatedDate;
        this.featuresList = featuresList;
    }

    public Project() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public String getSecretKey() {
        return secretKey;
    }

    public void setSecretKey(String secretKey) {
        this.secretKey = secretKey;
    }

    public Timestamp getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Timestamp createdDate) {
        this.createdDate = createdDate;
    }

    public Timestamp getLastUpdatedDate() {
        return lastUpdatedDate;
    }

    public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
        this.lastUpdatedDate = lastUpdatedDate;
    }

    public ArrayList<Feature> getFeaturesList() {
        return featuresList;
    }

    public void setFeaturesList(ArrayList<Feature> featuresList) {
        this.featuresList = featuresList;
    }
}
