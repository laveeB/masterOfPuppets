package model;

import java.util.ArrayList;

public class User {


    public String userName;
    public String userId;
    public ArrayList<Project> listOfProjects;

    public User(String userName, String userId, ArrayList<Project> listOfProjects) {
        this.userName = userName;
        this.userId = userId;
        this.listOfProjects = listOfProjects;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public ArrayList<Project> getListOfProjects() {
        return listOfProjects;
    }

    public void setListOfProjects(ArrayList<Project> listOfProjects) {
        this.listOfProjects = listOfProjects;
    }
}
