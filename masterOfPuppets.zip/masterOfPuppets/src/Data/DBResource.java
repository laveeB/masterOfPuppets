package Data;

import java.sql.SQLException;
import model.Project;
import model.Feature;
import java.util.ArrayList;

public abstract interface DBResource {

	public abstract void createProjectTable() throws SQLException;

	public abstract void createFeatureFlagsTable() throws SQLException;

	public abstract void saveProject(Project project) throws SQLException;

	public abstract void saveFeatureFlag(Feature feature) throws SQLException;

	public abstract void removeFeatureFlag(String featureName, String projectId) throws SQLException;

	public abstract void updateFeatureFlagName(String featureName, String projectId, String newName) throws SQLException;

	public abstract void updateFeatureFlagStatus(String featureName, String projectId, boolean status) throws SQLException;

	public abstract ArrayList<Project> getProjectFromDB() throws SQLException;

	public abstract ArrayList<Feature> getFeatureFlagsFromDB(String projectId) throws SQLException;

}
