package Data;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.Feature;
import model.Project;

public class DBResourceImpl implements DBResource {

    private Connection connection;

    @Override
    public void createProjectTable() throws SQLException {

        String query = "CREATE TABLE Projects(" +
                "projectId [VARCHAR](50) NOT NULL," +
                "projectName [VARCHAR](50) NOT NULL," +
                "secretKey [VARCHAR](100) NOT NULL," +
                "createdDate [TIMESTAMP] NOT NULL," +
                "lastUpdatedDate [TIMESTAMP] NOT NULL," +
                " PRIMARY KEY (projectId, secretKey));";

        PreparedStatement preparedStatement = connection.prepareCall(query);
        preparedStatement.executeQuery();
    }

    @Override
    public void createFeatureFlagsTable() throws SQLException {

        String query = "CREATE TABLE FeatureFlags(" +
                "projectId [VARCHAR](50) NOT NULL," +
                "featureName [VARCHAR](50) NOT NULL," +
                "isEnabled [VARCHAR](100) NOT NULL," +
                " PRIMARY KEY (projectId,featureName));";

        PreparedStatement preparedStatement = connection.prepareCall(query);
        preparedStatement.executeQuery();
    }

    @Override
    public void saveProject(Project project) throws SQLException {
        String insertEntry = "INSERT INTO Projects"
                + "(projectId, projectName, secretKey, createdDate, lastUpdatedDate) VALUES"
                + "(?,?,?,?,?)";

        PreparedStatement preparedStatement = connection.prepareStatement(insertEntry);

        preparedStatement.setString(1, project.getProjectId());
        preparedStatement.setString(2, project.getName());
        preparedStatement.setString(3, project.getSecretKey());
        preparedStatement.setTimestamp(4, project.getCreatedDate());
        preparedStatement.setTimestamp(5, project.getLastUpdatedDate());
        preparedStatement.executeQuery();
    }

    @Override
    public void saveFeatureFlag(Feature feature) throws SQLException {
        String insertEntry = "INSERT INTO FeatureFlags"
                + "(projectId, featureName, isEnabled) VALUES"
                + "(?,?,?)";

        PreparedStatement preparedStatement = connection.prepareStatement(insertEntry);

        preparedStatement.setString(1, feature.getProjectId());
        preparedStatement.setString(2, feature.getFeatureName());
        preparedStatement.setBoolean(3, feature.isEnabled());
        preparedStatement.executeQuery();
    }

    @Override
    public void removeFeatureFlag(String featureName, String projectId) throws SQLException {

        String removeQuery = "DELETE FROM FeatureFlags"
                + "WHERE featureName = ? and projectId= ?";

        PreparedStatement preparedStatement = connection.prepareCall(removeQuery);

        preparedStatement.setString(1, featureName);
        preparedStatement.setString(2, projectId);
        preparedStatement.executeQuery();

    }

    @Override
    public void updateFeatureFlagName(String featureName, String projectId, String newName) throws SQLException {
        String removeQuery = "UPDATE FeatureFlags" +
                "SET featureName = ?" +
                "WHERE featureName = ? and projectId= ?";

        PreparedStatement preparedStatement = connection.prepareCall(removeQuery);

        preparedStatement.setString(1, newName);
        preparedStatement.setString(2, featureName);
        preparedStatement.setString(3, projectId);
        preparedStatement.executeQuery();
    }

    @Override
    public void updateFeatureFlagStatus(String featureName, String projectId, boolean status) throws SQLException {
        String removeQuery = "UPDATE FeatureFlags" +
                "SET isEnabled = ?" +
                "WHERE featureName = ? and projectId= ?";

        PreparedStatement preparedStatement = connection.prepareCall(removeQuery);

        preparedStatement.setBoolean(1, status);
        preparedStatement.setString(2, featureName);
        preparedStatement.setString(3, projectId);
        preparedStatement.executeQuery();
    }

    @Override
    public ArrayList<Project> getProjectFromDB() throws SQLException {
        ArrayList<Project> projects = new ArrayList<>();
        String query = "SELECT * FROM Projects";
        PreparedStatement preparedStatement = connection.prepareCall(query);
        preparedStatement.executeQuery();

        ResultSet resultSet = preparedStatement.getResultSet();
        while (resultSet.next()) {
            Project project = getProject(resultSet);
            projects.add(project);
        }
        return projects;
    }

    @Override
    public ArrayList<Feature> getFeatureFlagsFromDB(String projectId) throws SQLException {
        ArrayList<Feature> features = new ArrayList<>();
        String query = "SELECT * FROM FeatureFlags WHERE projectId = ?";
        PreparedStatement preparedStatement = connection.prepareCall(query);
        preparedStatement.setString(1, projectId);
        preparedStatement.executeQuery();

        ResultSet resultSet = preparedStatement.getResultSet();
        while (resultSet.next()) {
            Feature feature = getFeatureFlag(resultSet);
            features.add(feature);
        }
        return features;
    }

    private Project getProject(ResultSet resultSet) {

        Project project = new Project();

        try {
            project.setProjectId(resultSet.getString("projectId"));
            project.setName(resultSet.getString("projectName"));
            project.setSecretKey(resultSet.getString("secretKey"));
            project.setCreatedDate(resultSet.getTimestamp("createdDate"));
            project.setLastUpdatedDate(resultSet.getTimestamp("lastUpdatedDate"));

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return project;
    }

    private Feature getFeatureFlag(ResultSet resultSet) {

        Feature feature = new Feature();

        try {
            feature.setProjectId(resultSet.getString("projectId"));
            feature.setFeatureName(resultSet.getString("featureName"));
            feature.setStatus(resultSet.getBoolean("isEnabled"));

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return feature;
    }


}
