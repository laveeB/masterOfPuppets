package interfaces;

import java.util.ArrayList;
import model.Feature;
import model.Project;

public abstract interface ProjectService {

	public abstract ArrayList<Project> getProjects();

	public abstract ArrayList<Feature> getProjectFeatureFlags(String projectId, String secretKey);

	public abstract Project createProject(String name);

	public abstract String keySecretKey(String projectName);

	public abstract Project getProject(String projectId);

}
