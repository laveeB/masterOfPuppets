package interfaces;

import model.Feature;

public abstract interface FeatureFlagService {

	public abstract Feature createFlag(String projectId, String name, boolean isEnabled);

	public abstract void changeFlagName(String projectId, String flagName, String newFlagName);

	public abstract void changeFlagStatus(String projectId, String flagName, boolean isEnabled);

	public abstract void delete(String projectId, String flagName);

}
